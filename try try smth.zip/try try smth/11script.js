const paragraph = document.querySelector('#paragraph');
const params = new URLSearchParams(window.location.search);
params.forEach((value)=>{
    paragraph.append(`${value} `);
});

(function(){

    function buildQuiz(){
        var question = Math.floor(Math.random()*myQuestions.length);
        const output = [];
        myQuestions.forEach(
          (currentQuestion, questionNumber) => {
            const answers = [];
            for(letter in currentQuestion.answers){
              answers.push(
                `<label>
                  <input type="radio" name="question${questionNumber}" value="${letter}">
                  ${letter} :
                  ${currentQuestion.answers[letter]}
                </label>`
              );
            }
            output.push(

              `<div class="slide">
                <div class="question"> ${currentQuestion.question} </div>
                <div class="answers"> ${answers.join("")} </div>
              </div>`
            );
          }
        );
        quizContainer.innerHTML = output.join('');
    }
    
    function showResults(){
  
        // gather answer containers from our quiz
        const answerContainers = quizContainer.querySelectorAll('.answers');
    
        // keep track of user's answers
        let numCorrect = 0;
    
        // for each question...
        myQuestions.forEach( (currentQuestion, questionNumber) => {
    
          // find selected answer
          const answerContainer = answerContainers[questionNumber];
          const selector = `input[name=question${questionNumber}]:checked`;
          const userAnswer = (answerContainer.querySelector(selector) || {}).value;
    
          // if answer is correct
          if(userAnswer === currentQuestion.correctAnswer){
            // add to the number of correct answers
            numCorrect++;
    
            // color the answers green
            // answerContainers[questionNumber].style.color = 'lightgreen';
          }
          // if answer is wrong or blank
          // else{
            // color the answers red
            // answerContainers[questionNumber].style.color = 'red';
          // }
        });
    
        // show number of correct answers out of total
        resultsContainer.innerHTML = `In total, you got ${numCorrect} out of ${myQuestions.length}`;
    }

    function showSlide(n) {
        slides[currentSlide].classList.remove('active-slide');
        slides[n].classList.add('active-slide');
        currentSlide = n;
        if(currentSlide === 0){
          previousButton.style.display = 'none';
        }
        else{
          previousButton.style.display = 'inline-block';
        }
        if(currentSlide === slides.length-1){
          nextButton.style.display = 'none';
          submitButton.style.display = 'inline-block';
        }
        else{
          nextButton.style.display = 'inline-block';
          submitButton.style.display = 'none';
        }
    }
    
    function showNextSlide() {
        showSlide(currentSlide + 1);
    }
    
    function showPreviousSlide() {
        showSlide(currentSlide - 1);
    }

    const quizContainer = document.getElementById('quiz');
    const resultsContainer = document.getElementById('results');
    const submitButton = document.getElementById('submit');

    const myQuestions = [
        {
          question: "Լուծել հավասարումը 3 - x > 1",
          answers: {
            a: "(-∞ ; 2]",
            b: "(2 ; +∞)",
            c: "(-∞ ; 2)",
            d: "[2 ; +∞)"
          },
          
          correctAnswer: "c"
        },
        {
          question: "Շրջանագծի հավասարումն է (x + 2)2 + (y + 1)2 = 13, գտնել շոշափողի թեքությունը",
          answers: {
            a: "-2/3",
            b: "Չգիտեմ",
            c: "5",
            d: "2/3"
          },
          correctAnswer: "a"
        },
        {
          question: "x<sup>2</sup> - 3|x - 2| - 4x = - 6 հավասարումից գտնել x-ը",
          answers: {
            a: "Չգիտեմ",
            b: "4, 0, 3, 1",
            c: "8, 9, 15",
          },
          correctAnswer: "b"
        },
        {
          question: "hello",
          answers: {
            a: "Չգիտեմ",
            b: "hi",
            c: "duck",
          },
          correctAnswer: "b"
        }
      ];

      buildQuiz();
  
    const previousButton = document.getElementById("previous");
    const nextButton = document.getElementById("next");
    const slides = document.querySelectorAll(".slide");
    let currentSlide = 0;
  
    showSlide(currentSlide);
  
    submitButton.addEventListener('click', showResults);
    previousButton.addEventListener("click", showPreviousSlide);
    nextButton.addEventListener("click", showNextSlide);
})();










// const question = document.getElementById('question');
// const choices = Array.from(document.getElementsByClassName('choice-text'));
// const progressText = document.getElementById('progressText');
// const scoreText = document.getElementById('score');
// const progressBarFull = document.getElementById('progressBarFull');
// const loader = document.getElementById('loader');
// const game = document.getElementById('game');
// let currentQuestion = {};
// let acceptingAnswers = false;
// let score = 0;
// let questionCounter = 0;
// let availableQuesions = [];

// let questions = [];

// fetch(
//    'https://opentdb.com/api.php?amount=10&category=9&difficulty=easy&type=multiple'
// )
//     .then((res) => {
//         return res.json();
//     })
//     .then((loadedQuestions) => {
//         questions = loadedQuestions.results.map((loadedQuestion) => {
//             const formattedQuestion = {
//                 question: loadedQuestion.question,
//             };

//             const answerChoices = [...loadedQuestion.incorrect_answers];
//             formattedQuestion.answer = Math.floor(Math.random() * 4) + 1;
//             answerChoices.splice(
//                 formattedQuestion.answer - 1,
//                 0,
//                 loadedQuestion.correct_answer
//             );

//             answerChoices.forEach((choice, index) => {
//                 formattedQuestion['choice' + (index + 1)] = choice;
//             });

//             return formattedQuestion;
//         });

//         startGame();
//     })
//     .catch((err) => {
//         console.error(err);
//     });

// //CONSTANTS
// const CORRECT_BONUS = 1;
// const MAX_QUESTIONS = 10;

// startGame = () => {
//     questionCounter = 0;
//     score = 0;
//     availableQuesions = [...questions];
//     getNewQuestion();
//     game.classList.remove('hidden');
//     loader.classList.add('hidden');
// };

// getNewQuestion = () => {
//     if (availableQuesions.length === 0 || questionCounter >= MAX_QUESTIONS) {
//         localStorage.setItem('mostRecentScore', score);
//         //go to the end page
//         return window.location.assign('end11.html');
//     }
//     questionCounter++;
//     progressText.innerText = `Question ${questionCounter}/${MAX_QUESTIONS}`;
//     //Update the progress bar
//     progressBarFull.style.width = `${(questionCounter / MAX_QUESTIONS) * 100}%`;

//     const questionIndex = Math.floor(Math.random() * availableQuesions.length);
//     currentQuestion = availableQuesions[questionIndex];
//     question.innerText = currentQuestion.question;

//     choices.forEach((choice) => {
//         const number = choice.dataset['number'];
//         choice.innerText = currentQuestion['choice' + number];
//     });

//     availableQuesions.splice(questionIndex, 1);
//     acceptingAnswers = true;
// };

// choices.forEach((choice) => {
//     choice.addEventListener('click', (e) => {
//         if (!acceptingAnswers) return;

//         acceptingAnswers = false;
//         const selectedChoice = e.target;
//         const selectedAnswer = selectedChoice.dataset['number'];

//         const classToApply =
//             selectedAnswer == currentQuestion.answer ? 'correct' : 'incorrect';

//         if (classToApply === 'correct') {
//             incrementScore(CORRECT_BONUS);
//         }

//         selectedChoice.parentElement.classList.add(classToApply);

//         setTimeout(() => {
//             selectedChoice.parentElement.classList.remove(classToApply);
//             getNewQuestion();
//         }, 1000);
//     });
// });

// incrementScore = (num) => {
//     score += num;
//     scoreText.innerText = score;
// };
