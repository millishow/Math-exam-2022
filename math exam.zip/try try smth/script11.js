var myQuestions = ['what is 1+1', 'what is 2+2', 'what is 3+3', 'what is 4+4', 'what is 5+5', 'what is 6+6', 'what is 7+7', 'what is 8+8', 'what is 9+9', 'what is 10+10',];
function  buildQuiz() {
  var ranQ = Math.floor(Math.random()*myQuestions.length);
  document.getElementById('quiz').innerHTML = myQuestions[ranQ];
  myQuestions.splice(ranQ, 2);
}

buildQuiz();